const user1 ={
   name: "Ana",
   id:1

};
const user2 ={
    name: "Maria",
    id:2
 
 };
 const user3 ={
    name: "Carlos",
    id:3
 
 };




let iden=document.getElementById("input").value;

const getUser = (id,cb) =>{
let array=[user1,user2,user3];
let ejemplo = array.find( elemento => elemento.id == id);

   if(ejemplo==undefined){
        cb("usuario no existe")
   }else{
        cb(null,ejemplo)
   }
   
}

getUser(iden,(err,ejemplo) =>{
 
    if(err){
        return console.log(err)
    }else{
        console.log(`user name is ${ejemplo.name}`);
    }
})