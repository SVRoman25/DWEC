const button=document.getElementById("button");
let array=[];
const lista = document.getElementById("lista");


//XMLHTTPRequest
/*
button.addEventListener("click", ()=>{
    
    let xhr 

    if(window.XMLHttpRequest){
        xhr=new XMLHttpRequest();
        
    }else{
        xhr = new ActiveXObject("Microsoft.XMLHTTP")
        
    }

    xhr.open("GET", "https://jsonplaceholder.typicode.com/users");

  
    xhr.addEventListener("load", (data)=>{
       array=(JSON.parse(data.target.response))
    
    });
   
    for(let i=0; i<array.length;i++){
        let fila = document.createElement("li");
     
        let texto = document.createTextNode(Object.values(array[i])[0]+"-"+Object.values(array[i])[1]);

        fila.appendChild(texto);
        lista.appendChild(fila);
    }

    xhr.send();

})
*/

//FETCH API
button.addEventListener("click", ()=>{

    fetch("https://jsonplaceholder.typicode.com/users")
        .then(res => res.ok? Promise.resolve(res):Promise.reject(res))
        .then(res => res.json())
        .then(res => {for(let i=0; i<res.length;i++){
            let fila = document.createElement("li");
         
            let texto = document.createTextNode(Object.values(res[i])[0]+"-"+Object.values(res[i])[1]);
    
            fila.appendChild(texto);
            lista.appendChild(fila);
        }
    })
       
    

})