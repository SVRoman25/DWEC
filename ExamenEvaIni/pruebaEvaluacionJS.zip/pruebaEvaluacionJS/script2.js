const insertar = () =>{
    window.alert("Insertar nuevo empleado");
    let numEmple = prompt("Numero de empleado");
    let dni = prompt("Dni del empleado");
    let nombre = prompt("Nombre del empleado");
    let apellido=prompt("Apellido del empleado");
 
    let prueba='<tr>'+'<td>'+numEmple+'<td>'+dni+'<td>'+nombre+'<td>'+apellido;
     
    let añadir = document.createElement("tr");

    añadir.innerHTML=prueba;
    document.getElementById("tablita").appendChild(añadir);
}